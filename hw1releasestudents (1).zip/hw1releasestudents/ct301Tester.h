#ifndef _CT301TESTER_H
#define _CT301TESTER_H

class flights; 
class flight; 

class ct301Tester 
{
public: 

void static inspectFlights(flights * allFlights);
void static inspectFlight(flight * f);

};

#endif